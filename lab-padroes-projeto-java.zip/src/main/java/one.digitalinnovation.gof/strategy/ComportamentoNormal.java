public class ComportamentoNormal {
  public void mover() {
    System.out.println("Movendo-se normalmente...");
  }
}