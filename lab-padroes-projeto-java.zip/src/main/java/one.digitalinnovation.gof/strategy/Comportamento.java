public interface Comportamento {
  void mover();
}