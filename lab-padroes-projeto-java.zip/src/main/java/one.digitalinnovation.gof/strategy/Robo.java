public class Robo {
  private Comportamento strategy;

  public void setComportamento(Comportamento comportamento){
      this.comportamento = comportamnto;
    }

  public void mover()
  comportamento.mover();
}