public class ComportamentoAgressivo {
  public void mover() {
    System.out.println("Movendo-se agressivamente...");
  }
}