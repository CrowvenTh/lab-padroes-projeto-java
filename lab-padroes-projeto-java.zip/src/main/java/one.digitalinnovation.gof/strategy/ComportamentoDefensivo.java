public class ComportamentoDefensivo {
  public void mover() {
    System.out.println("Movendo-se defensivamente...");
  }
}