import subSistema1crm.CrmService;
import subSistema2cep.CepApi;

public class Facade {

  public void migrarcliente(String nome, String cep) {
  
    String cidade = CepApi.getInstancia().recuperarCidade(cep);
    String estado = CepApi.getInstancia().recuperarCidade(cep);
    
    CrmService.gravarCliente(nome, cep, cidade, estado)
  }
}